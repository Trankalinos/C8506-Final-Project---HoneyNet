<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Join extends Application {

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     * 		http://example.com/index.php/welcome
     *	- or -  
     * 		http://example.com/index.php/welcome/index
     *	- or -
     * Since this controller is set as the default controller in 
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see http://codeigniter.com/user_guide/general/urls.html
     */
         
        // var $_info;
    
	public function index()
	{  
            $this->data['pagebody'] = "join_view";
            $this->data['pagetitle'] = "Join";
            // $this->data['notifier'] = $this->_notifier;
            $this->render('Join');
	}
        
        function register()
        {
            /*$this->load->library("form_validation");

            $this->form_validation->set_rules("fname", "First Name", "required|alpha");
            $this->form_validation->set_rules("lname", "Last Name", "required|alpha");
            $this->form_validation->set_rules("address", "Address", "required");
            $this->form_validation->set_rules("city", "City", "required");
            $this->form_validation->set_rules("province", "Province", "required");
            $this->form_validation->set_rules("postal", "Postal Code", "required|alpha_numeric");
            $this->form_validation->set_rules("phone", "Contact Number", "required|numeric|exact_length[10]");
            $this->form_validation->set_rules("email", "Contact Email", "required|valid_email");
            
            // $this->form_validation->set_rules("ccNumber", "Credit Card Number", "required|numeric|exact_length[16]");
            // $this->form_validation->set_rules("ccName", "Cardholder Name", "required");
            // $this->form_validation->set_rules("ccv", "CCV", "required|numeric|exact_length[3]");
            // $this->form_validation->set_rules("expire", "Expiry Date", "required|exact_length[5]");
            
            $this->form_validation->set_error_delimiters("<em class='error'>* ", "</em>");

            if ($this->form_validation->run() == false) {
                
                $this->index();
                
            } else {*/
                // $this->_notifier = "<h3>Your email was successfully sent. We will reply to you as soon as possible!</h3>";
                
                $this->confirmRegistration();
                // $this->createMember();
            // }
        }
        
        public function confirmRegistration()
        {
            // $this->_info['fname'] = set_value("fname");
            // $data['fname'] = htmlspecialchars($this->input->post('fname', false), ENT_COMPAT,'ISO-8859-1', true);
            $data['fname'] = $this->input->post('fname', false);
            $data['lname'] = $this->input->post("lname", false);
            $data['address'] = $this->input->post("address", false);
            $data['city'] = $this->input->post("city", false);
            $data['province'] = $this->input->post("province", false);
            $data['postal'] = $this->input->post("postal", false);
            $data['phone'] = $this->input->post("phone", false);
            $data['email'] = $this->input->post("email", false);

            
            $this->data['pagebody'] = "confirm_view";
            $this->data['pagetitle'] = "Join";
            
            // $this->data['fname'] = htmlspecialchars($data['fname'], ENT_COMPAT,'ISO-8859-1', true);
            // echo $data['fname'];
            // exit;
            // $this->data['fname'] = "<script>alert('xss');</script>";
            $this->data['fname'] = $data['fname'];
            $this->data['lname'] = $data['lname'];
            $this->data['address'] = $data['address'];
            $this->data['city'] = $data['city'];
            $this->data['province'] = $data['province'];
            $this->data['postal'] = $data['postal'];
            $this->data['phone'] = $data['phone'];
            $this->data['email'] = $data['email'];


            $this->render('Join');
        }
        
        function createMember() {
            /*$data['fname'] = set_value("fname");
            $data['lname'] = set_value("lname");
            $data['address'] = set_value("address");
            $data['city'] = set_value("city");
            $data['province'] = set_value("province");
            $data['postal'] = set_value("postal");
            $data['phone'] = set_value("phone");
            $data['email'] = set_value("email");*/
            /* $fname = set_value("fname");
             $fname = "'Tommy'); DROP TABLE c8506.cc";
             $this->member->add($data);
             $this->memberConfirmation($data);
             $this->notifyAdmin($data);*/   
            /*$fname = $data['fname'];
            $lname = $data['lname'];
            $address = $data['address'];
            $city = $data['city'];
            $province = $data['province'];
            $postal = $data['postal'];
            $phone = $data['phone'];
            $email = $data['email'];*/
            
            $fname = $this->input->post("fname", false);
            $lname = $this->input->post("lname", false);
            $address = $this->input->post("address", false);
            $city = $this->input->post("city", false);
            $province = $this->input->post("province", false);
            $postal = $this->input->post("postal", false);
            $phone = $this->input->post("phone", false);
            $email = $this->input->post("email", false);
            
            $query  = 'INSERT INTO Member (fname, lname, address, city, province, postal, phone, email, message) VALUES ('
                    .'"'.$fname.'","'.$lname.'","'.$address.'","'.$city.'","'.$province.'","'.$postal.'","'.$phone.'","'.$email.'")';
            
            $sqls = explode(';', $query);

            foreach($sqls as $command){
                    // echo $command;
                    $statement = $command . ";";
                    $this->db->query($statement);	
            }
            
            redirect('registered');
        }
        
        private function addCC() 
        {
            $data['ccNumber'] = set_value("ccNumber");
            $data['ccName'] = set_value("ccName");
            $data['ccv'] = set_value("ccv");
            $data['expire'] = set_value("expire");

            $this->cc->add($data);
        }
        
        /*private function memberConfirmation($data)
        {
            $this->load->library("email");
            $config['mailtype'] = "html";
            $this->email->initialize($config);
            
            $message = $this->load->view("payment_view", $data, true);

            $this->email->from("do-not-reply@creationcanada.com", "Creation Canada");
            $this->email->subject("Payment Confirmed - Thank you for your registration");

            $this->email->to($data['email']);

            $this->email->message($message);

            $this->email->send();
        }*/
        
        /*private function notifyAdmin($data) 
        {
            $this->load->library("email");
            $config['mailtype'] = "html";
            $this->email->initialize($config);
            
            $message = $this->load->view("notify_admin_view", $data, true);
            
            $this->email->from("notify-admin@creationcanada.com", "Creation Canada");
            $this->email->subject("Member Created - ".$data['fname']." ".$data['lname']);

            $this->email->to("david.tran_@outlook.com");

            $this->email->message($message);

            $this->email->send();
        }*/        
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */