<?php
if (!defined('APPPATH'))
    exit('No direct script access allowed');
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <style type="text/css">
            body {
                font-family: Calibri;
                color: #000;
                font-size: 11pt;
            }

            footer {
                font-size: 9pt;
            }
        </style>
    </head>

    <body>
        <div class="container">
        <div>
            <h1>Email for Creation Canada</h1>
        </div>
        <fieldset>
            <legend>Email Info</legend>
            <table border="0">
                <tr><th>Name: </th><td><?php echo $name; ?></td></tr>
                <tr><th>Email: </th><td><?php echo $email; ?></td></tr>
                <tr><th>Subject: </th><td><?php echo $subject; ?></td></tr>
            </table>
        </fieldset>
        <br />
            <h3>Message Contents:</h3>
            <p><?php echo $message; ?></p>
        <br />
        <br />
    <!-- end .container --></div>
    </body>
</html>