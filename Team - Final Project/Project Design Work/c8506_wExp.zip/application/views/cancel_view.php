<content>
    <div id="content">
        
        <div class="section">
            <h1>Cancel Membership</h1>
            
            <p>We respect your decision to cancel with us.</p>
            
            <p>*Required Fields</p>
            
            <div style="width: 80%; margin: auto;">
                <div style="float: left; width: 50%; padding-bottom: 30px;">
                    <?php
                        echo form_error("fname").'<br />';
                        echo form_error("lname").'<br />';
                        echo form_error("province").'<br />';
                        echo form_error("phone").'<br />';
                        echo form_error("ccNumber");
                    ?>
                </div>

                <div style="float: right; text-align:left; width: 50%; padding-bottom: 30px;">
                    <?php
                        echo form_error("address").'<br />';
                        echo form_error("city").'<br />';
                        echo form_error("postal").'<br />';
                        echo form_error("email").'<br />';
                    ?>
                </div>
            </div>
            <div style="clear: both;">
                <div class='memberForm'>
                    <h2>Member Contact &amp; Personal Information</h2>
                    <table class="form" cellpadding="0" cellspacing="0">
                        <?php
                            $this->load->helper("form");

                            echo form_open("cancel/confirm");

                            echo '<tr><td class="label">';
                            echo form_label("*First Name: ", "fname");
                            echo '</td>';
                            $data = array(
                                "name" => "fname",
                                "id" => "fname",
                                "value" => "",
                            );
                            echo '<td>';
                            echo form_input($data);
                            echo '</td>';
                            
                            echo '<td class="label">';
                            echo form_label("*Address: ", "address");
                            echo '</td>';
                            $data = array(
                                "name" => "address",
                                "id" => "address",
                                "value" => "",
                            );
                            echo '<td>';
                            echo form_input($data);
                            echo '</td></tr>';
                            
                            echo '<tr><td class="label">';
                            echo form_label("*Last Name: ", "lname");
                            echo '</td>';
                            $data = array(
                                "name" => "lname",
                                "id" => "lname",
                                "value" => "",
                            );
                            echo '<td>';
                            echo form_input($data);
                            echo '</td>';
                            
                            echo '<td class="label">';
                            echo form_label("*City: ", "city");
                            echo '</td>';
                            $data = array(
                                "name" => "city",
                                "id" => "city",
                                "value" => "",
                            );
                            echo '<td>';
                            echo form_input($data);
                            echo '</td></tr>';
                            
                            echo '<tr><td class="label">';
                            echo form_label("*Province: ", "province");
                            echo '</td>';
                            $data = array(
                                "name" => "province",
                                "id" => "province",
                                "value" => "",
                            );
                            echo '<td>';
                            echo form_input($data);
                            echo '</td>';

                            echo '<td class="label">';
                            echo form_label("*Postal Code: ", "postal");
                            echo '</td>';
                            $data = array(
                                "name" => "postal",
                                "id" => "postal",
                                "value" => "",
                            );
                            echo '<td>';
                            echo form_input($data);
                            echo '</td></tr>';
                            
                            echo '<tr><td class="label">';
                            echo form_label("*Contact Number: ", "phone");
                            echo '</td>';
                            $data = array(
                                "name" => "phone",
                                "id" => "phone",
                                "placeholder" => "(eg. ###-###-####)",
                                "value" => "",
                            );
                            echo '<td>';
                            echo form_input($data);
                            echo '</td>';
                            
                            echo '<td class="label">';
                            echo form_label("*Contact Email: ", "email");
                            echo '</td>';
                            $data = array(
                                "name" => "email",
                                "id" => "email",
                                "value" => "",
                            );
                            echo '<td>';
                            echo form_input($data);
                            echo '</td></tr>';
                            
                            echo '<tr><td class="label">';
                            echo form_label("*Credit Card: ", "ccNumber");
                            echo '</td>';
                            $data = array(
                                "name" => "ccNumber",
                                "id" => "ccNumber",
                                "value" => "",
                            );
                            echo '<td>';
                            echo form_input($data);
                            echo '</td></tr>';
                            
                            echo '<tr><td colspan="4">';
                            echo form_submit("cancel", "Cancel Membership");
                            echo '</td></tr>';
                            echo form_close();
                        ?>
                    </table>
                </div>
            </div>
        </div>
    </div>
</content>