<content>
    <div id="content">
        <div class="section">
            <h1>Registration Successful</h1>
            <p>Registration was successful. Payments will appear in your credit card
            statement within 2-3 business days. Administrators will let you know of
            the next gathering of the superior White Race.</p>
            
            <p><a href="<?php echo base_url(); ?>">Return Home</a></p>
        </div>
    </div>
</content>
