<content>
    <div id="content">
        
        <div class="section">
            <h1>Join Us</h1>
            
            <p>Registration fees are $150.00 per month. Registration includes weekly
            emails that will contain information on where we gather. The fee also
            includes membership coverage, group gatherings and other social get togethers
            to help further the vision of Creation.</p>
            
            <h2 style='text-align: center;'>Don't delay. Join the Movement of Creation!</h2>
            
            <p>*Required Fields</p>
            
            <!--<div style="width: 80%; margin: auto;">
                <div style="float: left; width: 50%; padding-bottom: 30px;">
                    <?php
                        // echo form_error("fname").'<br />';
                        // echo form_error("lname").'<br />';
                        // echo form_error("province").'<br />';
                        // echo form_error("phone").'<br />';
                    ?>
                </div>

                <div style="float: right; text-align:left; width: 50%; padding-bottom: 30px;">
                    <?php
                        // echo form_error("address").'<br />';
                        // echo form_error("city").'<br />';
                        // echo form_error("postal").'<br />';
                        // echo form_error("email").'<br />';
                    ?>
                </div>
            </div> -->
            
            <div style="clear: both;">
                <div class='memberForm'>
                    <h2>Member Contact &amp; Personal Information</h2>
                    <form action='<?php echo base_url();?>join/confirmRegistration' method='post'>
                    <table class="form" cellpadding="0" cellspacing="0">
                        
                        <?php
                            $this->load->helper("form");

                            // echo form_open("join/confirmRegistration");

                            echo '<tr><td class="label">';
                            echo form_label("*First Name: ", "fname");
                            echo '</td>';
                            $data = array(
                                "name" => "fname",
                                "id" => "fname",
                                "value" => set_value('fname'),
                            );
                            echo '<td>';
                            echo form_input($data);
                            echo '</td>';
                            
                            echo '<td class="label">';
                            echo form_label("*Address: ", "address");
                            echo '</td>';
                            $data = array(
                                "name" => "address",
                                "id" => "address",
                                "value" => set_value('address'),
                            );
                            echo '<td>';
                            echo form_input($data);
                            echo '</td></tr>';
                            
                            echo '<tr><td class="label">';
                            echo form_label("*Last Name: ", "lname");
                            echo '</td>';
                            $data = array(
                                "name" => "lname",
                                "id" => "lname",
                                "value" => set_value('lname'),
                            );
                            echo '<td>';
                            echo form_input($data);
                            echo '</td>';
                            
                            echo '<td class="label">';
                            echo form_label("*City: ", "city");
                            echo '</td>';
                            $data = array(
                                "name" => "city",
                                "id" => "city",
                                "value" => set_value('city'),
                            );
                            echo '<td>';
                            echo form_input($data);
                            echo '</td></tr>';
                            
                            echo '<tr><td class="label">';
                            echo form_label("*Province: ", "province");
                            echo '</td>';
                            $data = array(
                                "name" => "province",
                                "id" => "province",
                                "value" => set_value('province'),
                            );
                            echo '<td>';
                            echo form_input($data);
                            echo '</td>';

                            echo '<td class="label">';
                            echo form_label("*Postal Code: ", "postal");
                            echo '</td>';
                            $data = array(
                                "name" => "postal",
                                "id" => "postal",
                                "value" => set_value('postal'),
                            );
                            echo '<td>';
                            echo form_input($data);
                            echo '</td></tr>';
                            
                            echo '<tr><td class="label">';
                            echo form_label("*Contact Number: ", "phone");
                            echo '</td>';
                            $data = array(
                                "name" => "phone",
                                "id" => "phone",
                                "placeholder" => "(eg. ###-###-####)",
                                "value" => set_value('phone'),
                            );
                            echo '<td>';
                            echo form_input($data);
                            echo '</td>';
                            
                            echo '<td class="label">';
                            echo form_label("*Contact Email: ", "email");
                            echo '</td>';
                            $data = array(
                                "name" => "email",
                                "id" => "email",
                                "value" => set_value('email'),
                            );
                            echo '<td>';
                            echo form_input($data);
                            echo '</td></tr>';
                            
                            echo '<tr><td colspan="4">';
                            echo form_submit("joinSubmit", "Register!");
                            echo '</td></tr>';
                            echo form_close();
                        ?>
                    </table>
                    </form>
                </div>    
                
                <!-- 
                <div class='ccForm'>
                    <h2>Member Credit Card Information</h2>
                    <table class="form" cellpadding="0" cellspacing="0">             
                        <?php    
                            
                            /*echo '<tr><td class="label">';
                            echo form_label("*Cardholder Name: ", "ccName");
                            echo '</td>';
                            $data = array(
                                "name" => "ccName",
                                "id" => "ccName",
                                "placeholder" => "Enter exactly as shown on Card",
                                "value" => set_value('ccName'),
                            );
                            echo '<td>';
                            echo form_input($data);
                            echo '</td><td>';
                            echo form_error("ccName");
                            echo '</td>';
                            
                            echo '<tr><td class="label">';
                            echo form_label("*Credit Card: ", "ccNumber");
                            echo '</td>';
                            $data = array(
                                "name" => "ccNumber",
                                "id" => "ccNumber",
                                "value" => set_value('ccNumber'),
                            );
                            echo '<td>';
                            echo form_input($data);
                            echo '</td><td>';
                            echo form_error("ccNumber");
                            echo '</td>';
                            
                             echo '<tr><td class="label">';
                            echo form_label("*CCV: ", "ccv");
                            echo '</td>';
                            $data = array(
                                "name" => "ccv",
                                "id" => "ccv",
                                "value" => set_value('ccv'),
                            );
                            echo '<td>';
                            echo form_input($data);
                            echo '</td><td>';
                            echo form_error("ccv");
                            echo '</td>';
                            
                            echo '<tr><td class="label">';
                            echo form_label("*Expiry Date: ", "expire");
                            echo '</td>';
                            $data = array(
                                "name" => "expire",
                                "id" => "expire",
                                "placeholder" => "MM/YY",
                                "value" => set_value('expire'),
                            );
                            echo '<td>';
                            echo form_input($data);
                            echo '</td><td>';
                            echo form_error("expire");
                            echo '</td>';
                            
                            echo '<tr><td colspan="2">';
                            echo form_submit("joinSubmit", "Register!");
                            echo '</td></tr>';
                            echo form_close();*/
                        ?>
                    </table>
                </div> -->
            </div>
        </div>
    </div>
</content>