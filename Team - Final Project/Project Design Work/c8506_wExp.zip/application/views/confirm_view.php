<content>
    <div id="content">
        <div class="section">
            <h1>Confirm Registration Info</h1>
            <?php 
                $this->load->helper("form");
                $this->load->helper("string");
                echo form_open("join/createMember");
            ?>
            
            <div style="clear: both;">
                <div class='memberForm'><p>Are you sure that this information is correct?</p>
                    <table class="form" cellpadding="0" cellspacing="0">
                        <tbody>
                            <tr>
                                <th>First Name:</th><td>{fname}<input type="hidden" name="fname" value="{fname}" /></td>
                                <th>Last Name:</th><td>{lname}<input type="hidden" name="lname" value="{lname}" /></td>
                            </tr>
                            <tr>
                                <th>Address:</th><td>{address}<input type="hidden" name="address" value="{address}" /></td>
                                <th>City:</th><td>{city}<input type="hidden" name="city" value="{city}" /></td>
                            </tr>
                            <tr>
                                <th>Province:</th><td>{province}<input type="hidden" name="province" value="{province}" /></td>
                                <th>Postal Code:</th><td>{postal}<input type="hidden" name="postal" value="{postal}" /></td>
                            </tr>
                            <tr>
                                <th>Contact Phone:</th><td>{phone}<input type="hidden" name="phone" value="{phone}" /></td>
                                <th>Email Address:</th><td>{email}<input type="hidden" name="email" value='{email}' /></td>
                            </tr>
                            <?php 
                                echo '<tr><td colspan="2">';
                                echo form_submit("joinSubmit", "Confirm!");
                                echo '</td><td colspan="2" style="text-align: center; cell-align: bottom;">';
                                // echo form_submit("cancel", "Cancel");
                                echo "<a href='".base_url()."join'>Back to Registration</a>";
                                echo '</td></tr>';
                                echo form_close();
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</content>

