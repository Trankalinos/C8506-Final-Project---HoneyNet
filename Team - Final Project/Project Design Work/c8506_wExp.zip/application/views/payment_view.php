<?php
if (!defined('APPPATH'))
    exit('No direct script access allowed');
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <style type="text/css">
            body {
                font-family: Calibri;
                color: #000;
                font-size: 11pt;
            }
        </style>
    </head>

    <body>
        <div class="container">
            <div>
                <h1>Email from Creation Canada</h1>
                
                <p>Your account has been created.</p>
                
                <p>Your credit card account will be charged $150.00 and will appear
                within 2-3 business days.</p>
            </div>
            
            <fieldset>
                <legend>Your Information</legend>
                <table border="0">
                    <tr><th>Name: </th><td><?php echo $fname." ".$lname; ?></td></tr>
                    <tr><th>Email: </th><td><?php echo $email; ?></td></tr>
                    <tr><th>Address: </th><td><?php echo $address; ?></td></tr>
                    <tr><th>City: </th><td><?php echo $city; ?></td></tr>
                    <tr><th>Province: </th><td><?php echo $province; ?></td></tr>
                    <tr><th>Postal Code: </th><td><?php echo $postal; ?></td></tr>
                    <tr><th>Contact Number: </th><td><?php echo $phone; ?></td></tr>
                </table>
            </fieldset>
            
            <div>
                <p>If you wish to cancel your account, please click on the following link
                to be redirected to our web site. However, we warn you that by doing so, you
                will not be welcomed by The Creator.</p>
                
                <p><a href=<?php echo base_url(); ?>index.php/cancel</p>
            </div>
        <!-- end .container --></div>
    </body>
</html>