<content>
    <div id="content">
        <div class="section">
            <h1>Survival, Expansion &amp; Advancement of the White Race</h1>
            <p>
                Our beliefs are strongly reinforced by an overwhelming mass of substantiated evidence. 
                They are based on the eternal Laws of Nature; they are based on the lessons and 
                experience of history; furthermore; they are based on logic, common sense and 
                reality, not myth and fantasy. No other religion can honestly make this claim.
            </p>
                <img src="<?php echo base_url(); ?>assets/gold-eagle.jpg" />
            <p>
                We furthermore believe that in 6000 years of recorded history, Nature's Eternal Religion 
                is the most profound and meaningful religious book ever written for the survival of the 
                White Race. It is a fundamental creed, based on the eternal Laws of Nature for the survival, 
                expansion and advancement of the White Race, the noblest creation in Nature's realm. We are 
                confident that the White Race will soon return to reality, embrace our powerful new Religion, 
                regain control of its own destiny, and advance forward to new heights never before dreamed of.
            </p>
                
            <p>
                It is towards this noble objective, the survival, expansion and advancement of the 
                White Race, that Nature's Eternal Religion is dedicated. It is for this reason our 
                dynamic religion was founded. We call our religion Creativity, and members thereof, 
                Creators, because, we believe these words, in essence, best describe the characteristic 
                soul of the White Race.
            </p>
        </div>
        
        <div class='section'>
            <h1>Religion of Creationism</h1>
            <p>
                We completely reject the Judeo-democratic-Marxist values of today, and supplant them with 
                new and basic values, of which race is the foundation. We take a new, revolutionary and 
                dynamic approach to the problems that face the White Race today in its desperate struggle 
                for survival.
            </p>
            <p>
                Although our religion is new, the laws embodied in our religion are not new, nor are they 
                something we have invented. On the contrary, we have only observed and put into words that 
                which Nature in her eternal wisdom has decreed for the survival of all her creatures from 
                the beginning of time.
            </p>
                <img src="<?php echo base_url(); ?>assets/burningcross.jpg" />
            <p>
                Nor is it at all remarkable that we should have observed these laws and based our religion
                on them. What is most strange is that the creative White Race has not done so centuries 
                ago. In fact, it is amazing that the Romans and the Greeks failed to do so in their time. 
                Going back even further, it is hard to understand why the highly gifted Egyptians failed 
                to do so in their great White civilization 5000 years ago. Had the White Race done so in 
                its earlier history, it would not now be trapped in the idiotic and precarious struggle 
                for survival in which it now finds itself ensnared.
            </p>
        </div>
        
        <div class="section">
            <h1>The Path of God &amp; His Holiness</h1>
            <p>
                We believe that reality is more important than "believing" in the unsubstantiated ramblings 
                of a wild and over-stimulated imagination. We believe that facts substantiated by massive 
                evidence are a thousand times more valid and meaningful than supernatural claims that 
                not only are unsubstantiated, but fly in the face of reason. We refuse to accept on "faith" 
                ludicrous claims that repudiate historical evidence, geological evidence, scientific 
                evidence; and fallacious claims that repudiate every other kind of evidence. We believe 
                that evidence and judgment are basic in forming conclusions and decisions in all the 
                vital matters pertaining to our lives.
            </p>
            <p>
                We believe a religion that is detrimental to the survival of a race is a bad religion. A religion 
                that helps a race to survive, expand and advance is a good religion for that race. Our creed 
                is such a religion, and will have the most profound and far-reaching implications for the 
                benefit and welfare of the White Race.
            </p>
            <p>
                It is not our intention to make the White Race less religious. On the contrary, it is our 
                intention to have the White Race become much more strongly devoted to religion than it is 
                today, and above all, it is our objective to give the White Race a far superior religion 
                than the self-destructive, suicidal religion with which it is now burdened.
            </p>
            <p>
                We believe that the highest Law of Nature is the right of any species to survival, expansion 
                and advancement of its own kind. We deem that for the White Race, the right to survival, expansion 
                and advancement of its own people is not only the highest Law of Nature, but also the foundation 
                of our religious creed.
            </p>
        </div>
        
        <div class="section">
            <h1>Join us today! Restore your Faith in our Creator!</h1>
            <p>
                It is overwhelmingly clear that unless the White Race in this generation changes the suicidal 
                course on which it is now embarked it will miserably perish from the face of the earth, overrun 
                and inundated by a flood-tide of colored mongrels.
            </p>
            <p>
                We are confident that in the near future the White Race will rally, unite, and embrace the 
                Creativity program for its own survival.
            </p>
            <p>
                Furthermore, we are convinced that if only one-tenth of the time, energy, and money, were 
                spent on propagating our dynamic religion as is spent on keeping alive the sick and morbid 
                religions now undermining our race, that Creativity would spread like wildfire. We mean to 
                organize all our good people and expend that energy - and more. United and organized the 
                White Race is ten times more powerful than the rest of the world put together. We predict 
                that our religion, Creativity, will be the supreme religion of the future. We predict that 
                it will not only spread to all the corners of the earth, but will eventually supplant all 
                other religions, barring none. 
            </p>
                <img src="<?php echo base_url(); ?>assets/creativity-movement.jpg" />
            <p style="text-align: center;">
                We believe that such is inevitable.
            </p>
        </div>
    </div>
</content>
