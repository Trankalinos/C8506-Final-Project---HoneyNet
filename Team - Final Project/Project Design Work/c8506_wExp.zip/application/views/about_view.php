<content>
    <div id="content">
        <div class="section relative">
            <h1>About the Creativity Movement</h1>
            
            <img src="<?php echo base_url(); ?>assets/heroes.jpg" />
            
            <h2>Our Father - Ben Klassen</h2>
            <div class="img-container">
                <img style="margin: 0; float: left; padding-right: 30px;" src="<?php echo base_url(); ?>assets/ben-klassen.jpg" />
                <p>Ben (Bernhardt) Klassen</p>
                <p>born February 20, 1918 in Rudnerwiede, Ukraine</p>
                <p>died August 6, 1993 in Otto, North Carolina, United States</p>
            </div>
            
            <h2 style="text-align: right; clear: both;">Our Friend - Matt Hale</h2>
            <div class="img-container">
                <img style="margin: 0; float: right; padding-left: 30px;" src="<?php echo base_url(); ?>assets/matt-hale.jpg" />
                
                <p>Matthew F. Hale (born July 27, 1971), more commonly known as Matt Hale, was the third Pontifex Maximus and the 
                    founder of the group formerly known as the World Church of the Creator and now known as The Creativity Movement.</p>

                <p>Hale was raised in East Peoria, Illinois, a city on the Illinois River. By the age of 12, he was reading books 
                about National Socialism such as Adolf Hitler's Mein Kampf, and had formed a group at school.</p>

                <p>In August 1989, Hale entered Bradley University, studying political science. In September 1989, Hale began 
                writing editorials in the college newspaper, the Bradley Scout, espousing his views of White Separatism. 
                A student at Bradley, Robert Bingham, also a political science major, began a debate in the college newspaper 
                editorial about civil rights and the Ku Klux Klan. Upon coming out to give his surname, Matt Hale invited the Ku 
                Klux Klan to the campus of Bradley in the spring of 1990; the same year, he was expelled from Bradley. 
                At the age of 19, Hale burned an Israeli flag at a demonstration and was found guilty of violating an East 
                Peoria ordinance against open burning. The next year, he passed out racist pamphlets to patrons at a shopping mall 
                and was fined for littering. In May 1991, Hale and his brother allegedly threatened three African-Americans with a 
                gun, and he was arrested for mob action. Since he refused to tell police where his brother was, Hale was also 
                charged with felony obstruction of justice; he was convicted of obstruction, but won a reversal on appeal. 
                In 1992, Hale attacked a security guard at a mall and was charged with criminal trespass, resisting arrest, 
                aggravated battery and carrying a concealed weapon. For this attack, Hale was sentenced to 30 months probation 
                and six months house arrest.</p>

                <p>In 1993, Hale graduated from Bradley University and received a degree in political science. In 1996, Hale 
                founded the New Church of the Creator, a revival of Ben Klassen's religious group, that believes that the white 
                race are the creators of all worthwhile civilization. The church believes that a "racial holy war" is necessary 
                to attain a "white world" without Jews and non-whites and to this end it encourages its members to "populate the 
                lands of this earth with white people exclusively".</p>

                <p>After Hale was appointed "Pontifex Maximus", he changed the name of the organization to the World Church of the 
                Creator. The name was again changed to the Creativity Movement when a religious group in Oregon (the Church of 
                the Creator) sued Hale's group for trademark infringement.</p>

                <p>Hale graduated from Southern Illinois University School of Law in May 1998 and passed the bar in July of that 
                same year. On December 16, 1998, the Illinois Bar Committee on Character and Fitness rejected Hale's application 
                for a license to practice law. Hale appealed, and a hearing was held on April 10, 1999. On June 30, 1999, a 
                Hearing Panel of the Committee refused to certify that Hale had the requisite moral character and fitness to 
                practice law in Illinois. Two days after Hale was denied a license to practice law, a World Church of the Creator 
                member and college student, Benjamin Smith, resigned from The Church and went on a three-day shooting spree in 
                which he randomly targeted members of racial and ethnic minority groups in Illinois and Indiana. Beginning on 
                July 2, 1999, Smith shot nine Orthodox Jews walking to and from their synagogues in Chicago's West Rogers Park 
                neighborhood, killed two people, including former Northwestern University basketball coach Ricky Byrdsong, in 
                Evanston, Illinois, and a 26-year-old Korean graduate student,d Won-Joon Yoon, who was shot as he was on his way 
                to church in Bloomington, Indiana. Smith wounded nine others before committing suicide on July 4. Mark Potok, 
                director of intelligence for the Southern Poverty Law Center, believes that Smith may have acted in retaliation 
                after Hale's application to practice law was rejected.</p>

                <p>After Smith's shooting spree, Hale appeared on television and in newspapers saying, "We do urge hatred. 
                If you love something, you must be willing to hate that which threatens it." He also referred to non-whites 
                as "mud races." According to Hale, America should only be occupied by whites.During a television interview 
                that summer, Hale stated that his church didn't condone violent or illegal activities.</p>

                <p>In late 2002, Hale filed a class action lawsuit against Judge Joan Lefkow, the United States district court 
                judge presiding over his trademark case. Again in late 2002 and prior to his arrest, Hale denounced Lefkow 
                in a news conference, claiming that she was biased against him because she was married to a Jewish man and 
                had grandchildren who were biracial.</p>

                <p>On January 8, 2003, Hale was arrested, charged with soliciting an undercover FBI informant to kill Lefkow.</p>

                <p>On February 28, 2005, Lefkow's mother and husband were murdered at her home on Chicago's North Side. Chicago 
                Police revealed on March 10 that Bart Ross, a plaintiff in a medical malpractice case that Lefkow had dismissed,
                admitted to the murders in a suicide note written before shooting himself during a routine traffic stop 
                in Wisconsin the previous evening. The murders and suicide had no connection to Hale or Creativity.</p>

                <p>On April 6, 2005, Hale was sentenced to a 40-year prison term in Supermax State Prison for his 
                conviction for attempting to solicit the murder of Lefkow.</p>

                <p>Hale's projected release date is December 6, 2037. He will be 66 years old upon his release.</p>
            </div>    
        </div>
        
        <div class="section relative">
            <h1>The Sixteen Commandments</h1>
            <p>
                1. It is the avowed duty and holy responsibility of each generation to assure and secure for 
                all time the existence of the White Race upon the face of this planet.</p>
            <p>    
                2. Be fruitful and multiply. Do your part in helping to populate the world with your own 
                kind. It is our sacred goal to populate the lands of this earth with White people exclusively.</p>
            <p>
                3. Remember that the inferior colored races are our deadly enemies, and that the most 
                dangerous of all is the Jewish race. It is our immediate objective to relentlessly expand 
                the White Race, and keep shrinking our enemies.</p>
            <p>
                4. The guiding principle of all your actions shall be:What is best for the White Race?</p>
            <p>
                5. You shall keep your race pure. Pollution of the White Race is a heinous crime against 
                Nature and against your own race.</p>
            <p>
                6. Your first loyalty belongs to the White Race.</p>
            <p>
                7. Show preferential treatment in business dealings with members of your own race. 
                Phase out all dealings with Jews as soon as possible. Do not employ niggers or 
                other coloreds. Have social contacts only with members of your own racial family.</p>
            <p>
                8. Destroy and banish all Jewish thought and influence from society. Work hard 
                to bring about a White world as soon as possible.</p>
            <p>
                9. Work and Creativity are our genius. We regard work as a noble pursuit and our 
                willingness to work as a blessing to our race.</p>
            <p>
                10. Decide in early youth that during your lifetime you will make at least one major 
                lasting contribution to the White Race.</p>
            <p>
                11. Uphold the honor of your race at all time.</p>
            <p>
                12. It is our duty and our privilege to further Nature’s plan by striving towards the 
                advancement and improvement of our future generations.</p>
            <p>
                13. You shall honor, protect and venerate the sanctity of the family unit, and hold it 
                sacred. It is the present link in the long golden chain of our White Race.</p>
            <p>
                14. Throughout your life you shall faithfully uphold our pivotal creed of Blood, Soil and 
                Honor. Practice it diligently, for it is the heart of our faith.</p>
            <p>
                15. As a proud member of the White Race, think and act positively, be courageous, confident 
                and aggressive. Utilize constructively your creative ability.</p>
            <p>
                16. We, the Racial Comrades of the White Race, are determined to regain complete and 
                unconditional control of our own destiny.
            </p>
        </div>
        
        <div class="section relative">
            <h1>Our Fundamental Beliefs</h1>
            <p>Based on the Eternal Laws of Nature, History, Logic and Common Sense we Creators believe:</p>
            
            <p>1. WE BELIEVE that our Race is our Religion.</p>

            <p>2. WE BELIEVE that the White Race is Nature’s Finest.</p>

            <p>3. WE BELIEVE that Racial Loyalty is the greatest of all honors, 
            and racial treason is the worst of all crimes.</p>

            <p>4. WE BELIEVE that what is good for the White Race is the highest virtue, 
            and what is bad for the White Race is the ultimate sin.</p>

            <p>5. WE BELIEVE that the one and only, true and revolutionary White Racial 
            Religion -Creativity- is the only salvation for the White Race. To 
            the fulfillment of these Religious Beliefs we Creators forever pledge 
            our Lives, our Sacred Honor and our Religious Zeal.</p>
        </div>
    </div>
</content>

