<?php
if (!defined('APPPATH'))
    exit('No direct script access allowed');
?>

<!doctype>
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/style.css"/>
        
        <title>{title} - {pagetitle}</title>
    </head>
    <body>
        <div id="body">
            <header>
                <div id='navigation'>
                    <div id='title'>
                        <a href="<?php echo base_url(); ?>">
                            <img src="<?php echo base_url(); ?>assets/banner_latin.gif"/>
                        </a>
                    </div>
                    <ul class='nav'>
                        {menubar}
                    </ul>    
                </div>    
            </header>

            <div id="container">
                {content}
            </div>
            <div class="push"></div>
            <footer>
                <div id="footer">
                    <p>Copyright &copy; <?php echo date('Y'); ?> | All Rights Reserved.</p>
                </div>
            </footer>
        </div>
    </body>
</html>