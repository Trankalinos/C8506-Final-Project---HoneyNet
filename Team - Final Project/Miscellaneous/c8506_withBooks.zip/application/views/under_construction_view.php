<content>
    <div id="content">
        <div class="section alone">
            <h1>Error 404</h1>
            <h2>Page Currently Under Construction</h2>

            <p>We are working hard to have all the information ready for the dawn of 
            a new vision. We will have all the necessary key components to enlighten 
            and further the superiority of the White Race.</p>
        </div>        
    </div>
</content>