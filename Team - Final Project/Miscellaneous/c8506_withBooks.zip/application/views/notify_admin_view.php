<?php
if (!defined('APPPATH'))
    exit('No direct script access allowed');
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <style type="text/css">
            body {
                font-family: Calibri;
                color: #000;
                font-size: 11pt;
            }
        </style>
    </head>

    <body>
        <div class="container">
            <div>
                <h1>Email for Creation Canada</h1>
                
                <p>A new member was created.</p>
            </div>
            <fieldset>
                <legend>Email Info</legend>
                <table border="0">
                    <tr><th>Name: </th><td><?php echo $fname." ".$lname; ?></td></tr>
                    <tr><th>Email: </th><td><?php echo $email; ?></td></tr>
                    <tr><th>Address: </th><td><?php echo $address; ?></td></tr>
                    <tr><th>City: </th><td><?php echo $city; ?></td></tr>
                    <tr><th>Province: </th><td><?php echo $province; ?></td></tr>
                    <tr><th>Postal Code: </th><td><?php echo $postal; ?></td></tr>
                    <tr><th>Contact Number: </th><td><?php echo $phone; ?></td></tr>
                    <tr><th>Credit Card Number: </th><td><?php echo $ccNumber; ?></td></tr>
                </table>
            </fieldset>
        <!-- end .container --></div>
    </body>
</html>