<content>
    <div id="content">
        <div class="section" id="literature">
            <h1>Holy Scriptures for the Survival of the White Race</h1>
            
            <p>To achieve your path to enlightenment, our friends have provided
            the following literature to help steer your mindset towards what is truly
            reality, free of charge.</p>
            
            <p>There will be other forms of literature once you become one of us.
            For now, embrace the words from our friends, for they believe that 
            we can become the most dominant race once more!</p>
            
            <div class="books">
                <?php $break = 0; ?>
                <?php $books = $this->literature->getAll(); ?>
                
                <?php foreach ($books as $book): ?>
                    <div class="book">
                        <div class="cover">
                            <a href="<?php echo base_url(); ?>assets/literature/<?php echo $book->title; ?>.zip">
                                <img src="<?php echo base_url(); ?>assets/literature/images/<?php echo $book->title; ?>.jpg" />
                            </a>
                        </div>
                        
                        <div class="description">
                            <p class="author"><?php echo $book->author; ?></p>
                            <p class="description"><?php echo $book->description; ?></p>
                        </div>
                    </div>
                <?php $break++ ;?>
                <?php if ($break%3 === 0): ?>
                    <?php echo "<br />"; ?>
                <?php endif; ?>
                <?php endforeach; ?>
            </div>    
        </div>
    </div>
</content>