<?php

/**
 * Generic properties model, sorta like java.util.properties
 *
 * Implements get, put and remove
 *
 * Each such model is bound to a "specific"properties" database table, 
 * which is assumed to have two columns:
 * - (string) "key" (primary key) and 
 * - (string) "value" 
 * 
 * Usage:
 * 1. This script goes in application/models
 * 2. Add 'properties' to the models in application/config/autoload.php, after _mymodel
 * 
 * ------------------------------------------------------------------------
 */
class Member extends _mymodel {

    var $_valueField;
    
    // Constructor

    function __construct() {
        parent::__construct();
        $this->_tableName = get_class($this);
        $this->setTable('member', 'ccNumber');
    }
}
/* End of file Properties.php */
/* Location: application/models/properties.php */