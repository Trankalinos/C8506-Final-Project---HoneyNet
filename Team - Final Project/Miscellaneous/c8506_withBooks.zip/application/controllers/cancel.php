<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Cancel extends Application {

    var $_notifier = "";
    
    function index() {
        $this->data['pagebody'] = "cancel_view";
        $this->data['pagetitle'] = "Cancel";

        $this->render('Cancelled');
    }
    
    function confirm() {
        $this->load->library("form_validation");

        $this->form_validation->set_rules("fname", "First Name", "required|alpha");
        $this->form_validation->set_rules("lname", "Last Name", "required|alpha");
        $this->form_validation->set_rules("address", "Address", "required");
        $this->form_validation->set_rules("city", "City", "required");
        $this->form_validation->set_rules("province", "Province", "required");
        $this->form_validation->set_rules("postal", "Postal Code", "required|alpha_numeric");
        $this->form_validation->set_rules("phone", "Contact Number", "required|numeric|exact_length[10]");
        $this->form_validation->set_rules("email", "Contact Email", "required|valid_email");

        $this->form_validation->set_rules("ccNumber", "Credit Card Number", "required|numeric|exact_length[16]");
        
        $this->form_validation->set_error_delimiters("<em class='error'>* ", "</em>");

        if ($this->form_validation->run() == false) {

            $this->index();

        } else {
            $this->_notifier = "<h3>Cancellation Successful. We are displeased with your departure.</h3>";

            $this->index();
        }
    }
}