<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Join extends Application {

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     * 		http://example.com/index.php/welcome
     *	- or -  
     * 		http://example.com/index.php/welcome/index
     *	- or -
     * Since this controller is set as the default controller in 
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see http://codeigniter.com/user_guide/general/urls.html
     */
         
        // var $_notifier = "";
    
	public function index()
	{  
            $this->data['pagebody'] = "join_view";
            $this->data['pagetitle'] = "Join";
            // $this->data['notifier'] = $this->_notifier;
            $this->render('Join');
	}
        
        function register()
        {
            $this->load->library("form_validation");

            $this->form_validation->set_rules("fname", "First Name", "required|alpha");
            $this->form_validation->set_rules("lname", "Last Name", "required|alpha");
            $this->form_validation->set_rules("address", "Address", "required");
            $this->form_validation->set_rules("city", "City", "required");
            $this->form_validation->set_rules("province", "Province", "required");
            $this->form_validation->set_rules("postal", "Postal Code", "required|alpha_numeric");
            $this->form_validation->set_rules("phone", "Contact Number", "required|numeric|exact_length[10]");
            $this->form_validation->set_rules("email", "Contact Email", "required|valid_email");
            
            $this->form_validation->set_rules("ccNumber", "Credit Card Number", "required|numeric|exact_length[16]");
            $this->form_validation->set_rules("ccName", "Cardholder Name", "required");
            $this->form_validation->set_rules("ccv", "CCV", "required|numeric|exact_length[3]");
            $this->form_validation->set_rules("expire", "Expiry Date", "required|exact_length[5]");
            
            $this->form_validation->set_error_delimiters("<em class='error'>* ", "</em>");

            if ($this->form_validation->run() == false) {
                
                $this->index();
                
            } else {
                // $this->_notifier = "<h3>Your email was successfully sent. We will reply to you as soon as possible!</h3>";
                
                $this->confirmRegistration();
                
            }
        }
        
        private function confirmRegistration()
        {
            $this->createMember();
            $this->addCC();
            
            redirect('registered');
        }
        
        private function createMember() {
            $data['fname'] = set_value("fname");
            $data['lname'] = set_value("lname");
            $data['address'] = set_value("address");
            $data['city'] = set_value("city");
            $data['province'] = set_value("province");
            $data['postal'] = set_value("postal");
            $data['phone'] = set_value("phone");
            $data['email'] = set_value("email");
            $data['ccNumber'] = set_value("ccNumber");
            
            $this->member->add($data);
            // $this->memberConfirmation($data);
            // $this->notifyAdmin($data);
        }
        
        private function addCC() 
        {
            $data['ccNumber'] = set_value("ccNumber");
            $data['ccName'] = set_value("ccName");
            $data['ccv'] = set_value("ccv");
            $data['expire'] = set_value("expire");

            $this->cc->add($data);
        }
        
        /*private function memberConfirmation($data)
        {
            $this->load->library("email");
            $config['mailtype'] = "html";
            $this->email->initialize($config);
            
            $message = $this->load->view("payment_view", $data, true);

            $this->email->from("do-not-reply@creationcanada.com", "Creation Canada");
            $this->email->subject("Payment Confirmed - Thank you for your registration");

            $this->email->to($data['email']);

            $this->email->message($message);

            $this->email->send();
        }*/
        
        /*private function notifyAdmin($data) 
        {
            $this->load->library("email");
            $config['mailtype'] = "html";
            $this->email->initialize($config);
            
            $message = $this->load->view("notify_admin_view", $data, true);
            
            $this->email->from("notify-admin@creationcanada.com", "Creation Canada");
            $this->email->subject("Member Created - ".$data['fname']." ".$data['lname']);

            $this->email->to("david.tran_@outlook.com");

            $this->email->message($message);

            $this->email->send();
        }*/        
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */