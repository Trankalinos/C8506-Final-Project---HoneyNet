<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Registered extends Application {

    function index() {
        $this->data['pagebody'] = "register_view";
        $this->data['pagetitle'] = "Registered";

        $this->render('Registered');
    }
}