
</div>

<div id="footer">
<p><a href="http://www.codeigniter.com/">CodeIgniter</a>, by <a href="http://www.EllisLab.com">EllisLab</a> -  Version <?php echo APPVER ?></p>
<p>Page rendered in {elapsed_time}</p>
</div>

</body>
</html>