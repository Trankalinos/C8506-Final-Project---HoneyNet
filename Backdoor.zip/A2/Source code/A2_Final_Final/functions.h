#ifndef func
#define func
int check_arguments(int argc, char **argv, int *server, char **dest_host, char **src_host, char **password, char **command, char **interface);
int execute_server(const char *password, const char *src_addr, const char *interface);
int execute_client(const char *password, const char *dst_addr, const char *command);
#endif
