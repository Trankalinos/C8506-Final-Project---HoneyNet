
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

//checks arguments for validity
int check_arguments(int argc, char **argv, int *server, char **dest_host, char **src_host, char **password, char **command, char**interface)
{
	int count;
	char *my_string = NULL;
	int bytes_read = 1;
	size_t nbytes = 50;

	for(count=0; count < argc; ++count)
    {
		if(strcmp(argv[count], "-server") == 0)
		{
			*server = 1;
		}
		else if(count != argc - 1)
		{
			if(strcmp(argv[count], "-dest") == 0)
			{	
				if(strstr(argv[count + 1], "-"))
				{
					printf("You did not specify a dest.\n");
					return 0;
				}
				*dest_host = malloc(sizeof(argv[count + 1]));
				strncpy(*dest_host, argv[count + 1], strlen(argv[count + 1]));
			}
			else if(strcmp(argv[count], "-source") == 0)
			{
				if(strstr(argv[count + 1], "-"))
				{
					printf("You did not specify a source.\n");
					return 0;
				}
				*src_host = malloc(sizeof(argv[count + 1]));
				strncpy(*src_host, argv[count + 1], strlen(argv[count + 1]));
			}
			else if(strcmp(argv[count], "-pass") == 0)
			{
				if(strstr(argv[count + 1], "-"))
				{
					printf("You did not specify a password.\n");
					return 0;
				}
				*password = malloc(sizeof(argv[count + 1]));
				strncpy(*password, argv[count + 1], strlen(argv[count + 1]));
			}
			else if(strcmp(argv[count], "-int") == 0)
			{
				if(strstr(argv[count + 1], "-"))
				{
					printf("You did not specify a interface.\n");
					return 0;
				}
				*interface = malloc(sizeof(argv[count + 1]));
				strncpy(*interface, argv[count + 1], strlen(argv[count + 1]));
			}
		}	
	}
	if(*server == 1 && *src_host == NULL)
	{
		printf("You did must specify a source address if you want server mode.\n");
		return 0;
	}
	if(*server == 0 && *dest_host == NULL)
	{
		printf("You did must specify a source address if you want client mode.\n");
		return 0;
	}
	if(*password == NULL)
	{
		printf("You did must specify a password.\n");
		return 0;
	}


	if(*server == 1)
	{
		printf("Server mode started\n");
	}
	else
	{
		printf("Client mode started\n");
		printf("Type command: \n");
		bytes_read = getline(&my_string, &nbytes, stdin);
		*command = malloc(sizeof(my_string));
		strncpy(*command, my_string, bytes_read);
		printf("\n");
	}
	return 1;
}
